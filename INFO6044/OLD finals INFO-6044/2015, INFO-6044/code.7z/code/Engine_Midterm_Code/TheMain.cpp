#include "CMachineGun.h"
#include "CLASERGun.h"

#include <iostream>

int main()
{
	CMachineGun theGun;
	//CLASERGun theGun;


	for ( int x = 0; x != 50; x++ )
	{
		bool bWeFired = false;
		bool bWeHit = false;
		float damage = theGun.FireCalcDamage( bWeFired, bWeHit, true );
		std::cout << x << " : "
			      << "Fired: " << bWeFired << ", "
			      << "Hit: " << bWeHit << ", "
				  << "damage: " << damage << std::endl;
		theGun.StepOneSecond();
	}

	// Now the target isn't moving
	std::cout << std::endl;

	for ( int x = 0; x != 50; x++ )
	{
		bool bWeFired = false;
		bool bWeHit = false;
		float damage = theGun.FireCalcDamage( bWeFired, bWeHit, false );
		std::cout << x << " : "
			      << "Fired: " << bWeFired << ", "
			      << "Hit: " << bWeHit << ", "
				  << "damage: " << damage << std::endl;
		theGun.StepOneSecond();
	}	
	
	return 0;
}