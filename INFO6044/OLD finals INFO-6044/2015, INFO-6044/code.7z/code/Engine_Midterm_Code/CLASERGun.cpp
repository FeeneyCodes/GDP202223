#include "CLASERGun.h"

CLASERGun::CLASERGun()
{
	this->m_weight = 100.0f;
	this->m_damagePerSecond = 10.0f;
	this->m_coolDownTime = 5.0f;
	this->m_accuracy = 2.0f/5.0f;
	this->m_coolDownLeft = 0.0f;
	return;
}

std::string CLASERGun::getTypeName(void)
{
	return "LASER Gun";
}

float CLASERGun::getWeight(void)
{
	return this->m_weight;
}

float CLASERGun::getDamagePerSecond(void)
{
	return this->m_damagePerSecond;
}

float CLASERGun::getCoolDown(void)
{
	return this->m_coolDownTime;
}

float CLASERGun::getAccuracyPercentage(void)
{
	// Convert to a percentage
	return this->m_accuracy * 100.0f;
}

bool CLASERGun::bCanWeFire(void)
{
	if ( this->m_coolDownLeft > 0.0f )
	{
		return false;
	}
	return true;
}


float CLASERGun::m_pickRandZeroToOne(void)
{
	float r = static_cast <float> (rand()) / static_cast <float> (RAND_MAX - 1);
	return r;
}


float CLASERGun::FireCalcDamage(bool &bWeFired, bool &bWeHitTarget, bool bTargetMoving)
{
	if ( ! this->bCanWeFire() )
	{	// We can't fire, so potential damage is zero
		return 0.0f;
	}
	// We're firing
	bWeFired = true;
	// Reset the cooldown timer
	this->m_coolDownLeft = this->m_coolDownTime;

	// Is the target moving?
	if ( ! bTargetMoving )
	{	// It's a "sitting duck", so 100% accuracy
		bWeFired = true;
		bWeHitTarget = true;
		return this->m_damagePerSecond;
	}

	// Target IS moving
	if ( this->m_pickRandZeroToOne() < this->m_accuracy )
	{	// Yup, we hit
		bWeHitTarget = true;
		return this->m_damagePerSecond;
	}
	else
	{	// No, we missed (so did no damage)
		bWeHitTarget = false;
		return 0.0f;
	}
	// Should never happen
	return 0.0f;
}

void CLASERGun::StepOneSecond(void)
{
	// Cool down the weapon
	this->m_coolDownLeft--;
	if ( this->m_coolDownLeft < 0.0f )
	{
		this->m_coolDownLeft = 0.0f;
	}
	return;
}
