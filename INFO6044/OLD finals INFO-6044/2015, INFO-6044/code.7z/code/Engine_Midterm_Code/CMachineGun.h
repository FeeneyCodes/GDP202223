#ifndef _CMachineGun_HG_
#define _CMachineGun_HG_

#include <string>

class CMachineGun
{
public:
	CMachineGun();
	std::string getTypeName(void);		// Returns "Machine Gun"

	float getWeight(void);
	float getDamagePerSecond(void);
	float getCoolDown(void);
	float getAccuracyPercentage(void);

	bool bCanWeFire(void);
	// Fires the weapon if we can. If we can't, returns zero.
	// If we hit, bDidWeHit = true, and the damage is returned, 
	//	otherwise we return zero
	// If the target ISN'T moving, the we hit every time (i.e. accuracy = 100%)
	float FireCalcDamage(bool &bWeFired, bool &bWeHitTarget, bool bTargetMoving);

	void StepOneSecond(void);
private:
	float m_weight;
	float m_damagePerSecond;
	float m_coolDownTime;
	float m_accuracy;
	float m_coolDownLeft;
	float m_pickRandZeroToOne(void);

};

#endif